<?php
$config = [
	"host" => "mail.yourdomain.com",
	"username" => "hi@yourdomain.com",
	"password" => "secret",
	"secure" => "ssl", // ssl or tls
	"port" => 465,
	"sendTo" => "hi@yourdomain.com",
	"from" => "no-reply@yourdomain.com",
	"fromName" => "Your Company"
];